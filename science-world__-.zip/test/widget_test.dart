import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:science_world/main.dart';

void main() {
  testWidgets('App renders splash', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: ScienceWorldApp()));
    expect(find.byType(MaterialApp), findsOneWidget);
  });
}